"""Cliente Twelve Data com failover de chaves e mensagens sem expor credenciais."""
import os, time
import requests
BASE_URL='https://api.twelvedata.com'
class TwelveDataError(RuntimeError):pass
class TwelveDataSource:
    def __init__(self,api_keys=None,timeout=15,session=None):
        if api_keys is None:
            api_keys=[os.getenv(f'TWELVE_DATA_API_KEY_{i}','').strip() for i in range(1,5)]
            if not any(api_keys):api_keys=[os.getenv('TWELVE_DATA_API_KEY','').strip()]
        self.api_keys=[k.strip() for k in (api_keys or []) if isinstance(k,str) and k.strip()]
        self.timeout=max(3,int(timeout)); self.session=session or requests.Session(); self._key_cursor=0
    def _request(self,endpoint,params=None):
        if not self.api_keys:raise TwelveDataError('Nenhuma chave da Twelve Data foi configurada.')
        errors=[]; start=self._key_cursor%len(self.api_keys)
        for offset in range(len(self.api_keys)):
            index=(start+offset)%len(self.api_keys); query=dict(params or {}); query['apikey']=self.api_keys[index]
            try:
                response=self.session.get(f'{BASE_URL}/{endpoint.lstrip("/")}',params=query,timeout=self.timeout)
                try:payload=response.json()
                except ValueError:payload={}
                msg=str(payload.get('message',payload.get('code',''))) if isinstance(payload,dict) else ''
                bad=response.status_code in (401,403,429) or (isinstance(payload,dict) and payload.get('status')=='error')
                if bad:errors.append(f'chave {index+1}: HTTP {response.status_code} {msg[:100]}');continue
                response.raise_for_status()
                if not isinstance(payload,dict):raise TwelveDataError('Resposta inesperada da Twelve Data.')
                self._key_cursor=index; return payload
            except (requests.RequestException,TwelveDataError) as exc:errors.append(f'chave {index+1}: {str(exc)[:100]}')
        raise TwelveDataError('Todas as chaves falharam. Verifique validade, plano e limites da Twelve Data. '+'; '.join(errors))
    def get_candles(self,symbol,interval='5min',outputsize=24,closed_only=True):
        payload=self._request('time_series',{'symbol':symbol,'interval':interval,'outputsize':max(5,min(5000,int(outputsize))),'order':'ASC','format':'JSON'})
        values=payload.get('values')
        if not isinstance(values,list):raise TwelveDataError('A API não retornou candles para o símbolo solicitado.')
        candles=[]
        for item in values:
            try:candles.append({'datetime':str(item.get('datetime','')),'open':float(item['open']),'high':float(item['high']),'low':float(item['low']),'close':float(item['close']),'volume':float(item.get('volume') or 0)})
            except (KeyError,TypeError,ValueError):continue
        candles.sort(key=lambda x:x['datetime'])
        if closed_only and len(candles)>1:candles=candles[:-1]
        return candles
    def get_candles_batch(self,symbols,interval='5min',outputsize=24,closed_only=True,pause_seconds=.15):
        data,errors={},{}
        for symbol in symbols:
            try:data[symbol]=self.get_candles(symbol,interval,outputsize,closed_only)
            except TwelveDataError as exc:errors[symbol]=str(exc)
            if pause_seconds:time.sleep(pause_seconds)
        return {'data':data,'errors':errors}
    def get_forex_pairs(self):
        payload=self._request('forex_pairs',{}); values=payload.get('data',payload.get('values',[])); out=[]
        if isinstance(values,list):
            for item in values:
                symbol=item.get('symbol') if isinstance(item,dict) else None
                if symbol:out.append(str(symbol).replace(' ','').upper())
        return out
    def test_connection(self):
        if not self.api_keys:return {'success':False,'message':'Nenhuma chave configurada.'}
        try:self._request('time_series',{'symbol':'EUR/USD','interval':'1min','outputsize':2,'format':'JSON'});return {'success':True,'message':'Conexão aceita pela Twelve Data.'}
        except Exception:return {'success':False,'message':'Falha na conexão. Confira a chave, os créditos e as permissões do plano.'}
    def test_all_keys(self):
        out=[]
        for i,key in enumerate(self.api_keys,1):
            result=TwelveDataSource([key],timeout=self.timeout).test_connection();out.append({'key_number':i,'success':result['success'],'message':result['message']})
        return out
