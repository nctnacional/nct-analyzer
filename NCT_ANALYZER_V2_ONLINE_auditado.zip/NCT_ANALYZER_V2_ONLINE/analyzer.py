"""Análise de correlação e sincronização direcional para pares FX."""
from math import isfinite, sqrt
from statistics import mean

def safe_float(value, default=0.0):
    try:
        result = float(value)
        return result if isfinite(result) else default
    except (TypeError, ValueError, OverflowError):
        return default

def clamp(value, low=0.0, high=100.0):
    return max(low, min(high, safe_float(value, low)))

def normalized_returns(candles):
    valid=[]
    for c in candles or []:
        close=safe_float(c.get('close'),-1)
        if close>0: valid.append((str(c.get('datetime',c.get('timestamp',''))),close))
    valid.sort(key=lambda x:x[0])
    return [(valid[i][0],valid[i][1]/valid[i-1][1]-1.0) for i in range(1,len(valid))]

def pearson(xs,ys):
    n=min(len(xs),len(ys))
    if n<3:return 0.0
    xs,ys=xs[-n:],ys[-n:]; mx,my=mean(xs),mean(ys)
    dx,dy=[x-mx for x in xs],[y-my for y in ys]
    denom=sqrt(sum(x*x for x in dx)*sum(y*y for y in dy))
    return max(-1.0,min(1.0,sum(a*b for a,b in zip(dx,dy))/denom)) if denom>1e-15 else 0.0

def directional_agreement(xs,ys):
    pairs=[(a,b) for a,b in zip(xs[-min(len(xs),len(ys)):],ys[-min(len(xs),len(ys)):]) if abs(a)>1e-12 and abs(b)>1e-12]
    return sum((a>0)==(b>0) for a,b in pairs)/len(pairs) if pairs else 0.0

def pair_similarity(xs,ys):
    n=min(len(xs),len(ys))
    if n<3:return 0.0
    return round(clamp((max(0.0,pearson(xs[-n:],ys[-n:]))*.6+directional_agreement(xs[-n:],ys[-n:])*.4)*100),2)

def summarize_pair(symbol,candles):
    returns=normalized_returns(candles); vals=[r for _,r in returns]
    net=0.0
    if vals:
        compounded=1.0
        for value in vals:compounded*=1.0+value
        net=(compounded-1.0)*100
    pos=sum(v>0 for v in vals); neg=sum(v<0 for v in vals)
    return {'symbol':symbol,'candles':len(candles or []),'returns':vals,'net_change_pct':round(net,5),'strength':round(mean([abs(v) for v in vals])*100,6) if vals else 0.0,'direction':'ALTA' if net>0 else 'BAIXA' if net<0 else 'NEUTRO','positive_candles':pos,'negative_candles':neg,'directional_consistency_pct':round(100*max(pos,neg)/len(vals),2) if vals else 0.0,'last_timestamp':returns[-1][0] if returns else None}

def analyze_market(candle_map,leaders_count=4,followers_per_leader=6,min_similarity=85.0):
    summaries={s:summarize_pair(s,c) for s,c in (candle_map or {}).items()}
    usable={s:v for s,v in summaries.items() if len(v['returns'])>=3}
    scores={}
    for s,info in usable.items():
        peers=[pair_similarity(info['returns'],other['returns']) for osym,other in usable.items() if osym!=s]
        scores[s]=round((mean(peers) if peers else 0.0)*.75+min(25.0,info['strength']*1000),2)
    order=sorted(usable,key=lambda s:(scores.get(s,0),abs(usable[s]['net_change_pct'])),reverse=True)
    assigned=set(); groups=[]
    for leader in order:
        if leader in assigned or len(groups)>=max(1,int(leaders_count)):continue
        candidates=[]
        for sym,info in usable.items():
            if sym==leader or sym in assigned:continue
            sim=pair_similarity(usable[leader]['returns'],info['returns'])
            if sim>=float(min_similarity):candidates.append({'symbol':sym,'similarity':sim,'direction':info['direction'],'net_change_pct':info['net_change_pct'],'strength':info['strength']})
        candidates.sort(key=lambda x:x['similarity'],reverse=True); followers=candidates[:max(0,int(followers_per_leader))]
        assigned.add(leader); assigned.update(x['symbol'] for x in followers)
        v=usable[leader]
        groups.append({'leader':{'symbol':leader,'score':scores.get(leader,0),'direction':v['direction'],'net_change_pct':v['net_change_pct'],'strength':v['strength'],'candles':v['candles']},'followers':followers})
    return {'generated_at':None,'assets_analyzed':len(summaries),'assets_with_enough_data':len(usable),'leaders':groups,'assets':[{k:v for k,v in item.items() if k!='returns'} for item in sorted(summaries.values(),key=lambda x:x['symbol'])],'message':'Análise concluída.' if usable else 'Dados insuficientes para calcular similaridade; verifique API, pares e janela de candles.'}
