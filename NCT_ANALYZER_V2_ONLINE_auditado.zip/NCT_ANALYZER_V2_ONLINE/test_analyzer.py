from analyzer import analyze_market, pair_similarity, safe_float
from datetime import datetime, timedelta

assert safe_float('nan', 9) == 9
assert safe_float('bad', 9) == 9
returns = [0.01, 0.02, -0.005, 0.03, 0.015]
assert pair_similarity(returns, returns) > 99
base = datetime(2026, 1, 1)
candles, close = [], 1.0
for i, ret in enumerate(returns):
    close *= 1 + ret
    candles.append({'datetime': (base + timedelta(minutes=5*i)).isoformat(), 'close': close})
result = analyze_market({'EUR/USD': candles, 'GBP/USD': candles}, 2, 2, 50)
assert result['assets_analyzed'] == 2
assert result['assets_with_enough_data'] == 2
assert len(result['leaders']) >= 1
print('OK: safe_float, similaridade e análise de pares.')
