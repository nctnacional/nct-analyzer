"""Worker separado para Render Background Worker: python worker.py"""
import logging,time
from datetime import datetime,timezone
from app import app,User,UserSettings,API_KEY_FIELDS,decrypt_secret,db,DEFAULT_PAIRS
from data_source import TwelveDataSource,TwelveDataError
from analyzer import analyze_market
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
log=logging.getLogger('nct-worker')

def run_user_analysis(settings):
    keys=[decrypt_secret(getattr(settings,f)) for f in API_KEY_FIELDS];keys=[k for k in keys if k]
    if not keys:raise TwelveDataError('Nenhuma chave de API disponível para este usuário.')
    source=TwelveDataSource(api_keys=keys)
    pairs=list(DEFAULT_PAIRS) if settings.automatic_pairs else (settings.pairs_json or list(DEFAULT_PAIRS))
    if not isinstance(pairs,list) or not pairs:pairs=list(DEFAULT_PAIRS)
    candle_map,failures={},{}
    for symbol in pairs[:100]:
        try:
            candles=source.get_candles(symbol,settings.timeframe,settings.window_candles,settings.closed_candles_only)
            if candles:candle_map[symbol]=candles
            else:failures[symbol]='Nenhum candle retornado.'
        except Exception as exc:failures[symbol]=str(exc)[:250]
    if not candle_map:raise TwelveDataError('Nenhum par retornou candles. Verifique o plano e os símbolos da Twelve Data.')
    result=analyze_market(candle_map,settings.leaders,settings.followers_per_leader,settings.min_similarity)
    result['generated_at']=datetime.now(timezone.utc).isoformat();result['failed_symbols']=failures;result['configured_symbols']=len(pairs)
    return result

def run_once():
    with app.app_context():
        enabled=UserSettings.query.filter_by(analysis_enabled=True).all();now=datetime.now(timezone.utc)
        for settings in enabled:
            last=settings.last_analysis_at
            if last is not None:
                if last.tzinfo is None:last=last.replace(tzinfo=timezone.utc)
                if (now-last).total_seconds()<max(60,int(settings.update_seconds or 180)):continue
            user=db.session.get(User,settings.user_id)
            if not user or not user.is_active_account:
                settings.analysis_enabled=False;db.session.commit();continue
            try:
                result=run_user_analysis(settings);settings.last_results_json=result;settings.last_analysis_at=datetime.now(timezone.utc);settings.last_analysis_error=None;db.session.commit()
                log.info('Análise concluída para user_id=%s; ativos=%s',settings.user_id,result.get('assets_analyzed'))
            except Exception as exc:
                settings.last_analysis_error=str(exc)[:500];settings.last_analysis_at=datetime.now(timezone.utc);db.session.commit()
                log.warning('Análise falhou para user_id=%s: %s',settings.user_id,str(exc)[:250])
        db.session.remove()

def main():
    log.info('NCT_ANALYZER_V2_ONLINE worker iniciado.')
    while True:
        start=time.monotonic();run_once();time.sleep(max(5,15-(time.monotonic()-start)))
if __name__=='__main__':main()
