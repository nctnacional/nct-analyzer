# NCT_ANALYZER_V2_ONLINE — pacote auditado

Aplicação Flask independente do projeto CIM. Inclui cadastro/login, banco persistente, chaves Twelve Data criptografadas por usuário e um Background Worker que coleta candles e grava resultados sem depender do navegador aberto.

## Arquivos

- `app.py`: autenticação, configurações, gestão de chaves, rotas API, administração e CSRF.
- `analyzer.py`: variação, direção, correlação positiva e agrupamento de líderes/seguidores.
- `data_source.py`: cliente Twelve Data e failover entre chaves.
- `worker.py`: coleta/análise em segundo plano.
- `extensions.py`: instância compartilhada do SQLAlchemy.
- `templates/`, `static/`: páginas e JavaScript/CSS do painel.
- `render.yaml`: configuração inicial do Blueprint Render (Web, Worker e PostgreSQL).

## Publicação no Render

1. Extraia a pasta e envie todo o conteúdo para um repositório GitHub privado novo `NCT_ANALYZER_V2_ONLINE`. Não misture arquivos do CIM nem do projeto local antigo.
2. No Render, crie um Blueprint a partir do repositório e revise `render.yaml`. Alternativamente, crie um Web Service, um Background Worker e um PostgreSQL.
3. Gere uma chave Fernet localmente: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`.
4. Defina `ENCRYPTION_KEY` no serviço web e no worker com o mesmo valor. **Não altere essa chave depois de salvar API keys**, pois elas ficariam ilegíveis.
5. Configure `DATABASE_URL` nos dois serviços apontando para o mesmo PostgreSQL persistente. Configure a mesma `SECRET_KEY` nos dois serviços; o Blueprint a compartilha.
6. Não envie `.env` nem chaves da Twelve Data para o GitHub. `SECRET_KEY`, `ENCRYPTION_KEY` e `DATABASE_URL` são variáveis de ambiente; as chaves Twelve Data são inseridas por cada usuário no painel.
7. Comandos de inicialização:
   - Web: `gunicorn --workers 2 --threads 4 --timeout 120 --access-logfile - --error-logfile - app:app`
   - Worker: `python worker.py`
8. Faça o deploy e abra o URL do Web Service. `/healthz` deve retornar `{"ok": true, "service": "NCT_ANALYZER_V2_ONLINE"}`.
9. Crie sua conta pela página inicial. A senha precisa ter no mínimo 12 caracteres.
10. Para criar/promover o administrador, abra o Shell do Web Service e execute `flask --app app criar-admin`; informe e-mail e senha no prompt. Para promover conta existente, use o mesmo e-mail.
11. Entre no painel, salve a(s) chave(s) Twelve Data, teste-as, confira os pares e clique em **Iniciar análise**. O Background Worker precisa estar `Live`.

## Variáveis obrigatórias em produção

- `SECRET_KEY`: segredo estável da sessão Flask.
- `ENCRYPTION_KEY`: chave Fernet estável e idêntica no web e worker.
- `DATABASE_URL`: URL do PostgreSQL persistente compartilhado.
- `FLASK_ENV=production`.

## Teste local (Windows PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:SECRET_KEY = "troque-por-um-segredo-local-longo"
$env:ENCRYPTION_KEY = (py -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())")
$env:DATABASE_URL = "sqlite:///nct_online.db"
$env:FLASK_ENV = "development"
flask --app app run --debug
```

Em outro terminal, ative o ambiente e execute `python worker.py`. SQLite serve apenas para teste local; use PostgreSQL em produção.

## Limitações que precisam ser consideradas

- `analysis_enabled` é o estado salvo no banco; o worker separado é quem executa coleta e análise.
- `closed_candles_only` remove conservadoramente o último candle retornado. Valide isso com os intervalos e a resposta real da Twelve Data antes de confiar nos números.
- `automatic_pairs` usa os pares padrão do servidor; não representa varredura ilimitada de todos os símbolos.
- A coleta usa uma chamada por par e por usuário ativo. Limites/créditos do provedor podem impedir coleta em escala; comece com poucos pares.
- `db.create_all()` cria tabelas ausentes, mas não migra esquema antigo. Faça backup e valide antes de apontar esta versão para um banco já usado.
- O score é uma heurística estatística de similaridade, não previsão garantida nem recomendação financeira. Não há execução de ordens.

## Checklist pós-publicação

- [ ] `/healthz` responde corretamente.
- [ ] Cadastro funciona para dois e-mails diferentes.
- [ ] Cada conta só vê suas configurações e chaves.
- [ ] Teste de chave funciona sem expor o segredo.
- [ ] Web Service e Background Worker estão ativos.
- [ ] Depois de iniciar, `last_analysis_at` e resultados são atualizados.
- [ ] Depois de parar, a conta deixa de ser processada.
- [ ] Reinícios não invalidam sessões nem credenciais salvas.
