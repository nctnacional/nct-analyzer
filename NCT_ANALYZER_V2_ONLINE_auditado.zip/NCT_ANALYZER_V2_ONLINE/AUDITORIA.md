# Relatório de auditoria — NCT_ANALYZER_V2_ONLINE

## Resultado geral

A versão anterior tinha a camada web e as rotas de configuração, mas não executava a análise apenas por marcar `analysis_enabled`. O pacote desta entrega conecta um Background Worker ao estado salvo no PostgreSQL e fornece os módulos auxiliares necessários.

## Correções feitas neste pacote

1. **Worker real:** `worker.py` consulta usuários habilitados, busca candles, calcula resultados e grava `last_results_json`, `last_analysis_at` e `last_analysis_error`. O worker é serviço separado do processo web.
2. **`safe_float`:** corrigida a referência à variável indefinida `converted_value`; agora valida o próprio resultado convertido e trata `NaN`/infinito.
3. **CSRF:** proteção reativada. Os formulários têm token e o JavaScript envia `X-CSRFToken`. Erros 400 têm resposta segura.
4. **Banco em produção:** o app falha na inicialização se `DATABASE_URL` estiver ausente em produção, evitando cair silenciosamente em SQLite efêmero.
5. **Segredos:** as chaves Twelve Data continuam criptografadas com Fernet; o estado retorna apenas indicador e chave mascarada, nunca o valor em texto puro.
6. **Estado das chaves:** `/api/state` retorna o estado individual das quatro posições, sem assumir que chaves configuradas estão necessariamente nas primeiras posições.
7. **Painel conectado:** botões de salvar/testar/remover chaves, salvar configurações, iniciar/parar e atualizar resultados chamam as rotas reais. Os resultados exibidos não são valores de gráfico fixos.
8. **Conta multiusuário:** cadastro continua permitindo e-mails diferentes, com unicidade no banco e configurações isoladas por `user_id`.
9. **Publicação:** adicionados templates de login/cadastro/dashboard/admin, `extensions.py`, `requirements.txt`, `.gitignore`, `.env.example`, `render.yaml`, testes básicos e instruções.

## Verificações executadas neste ambiente

- `python -m compileall`: aprovado para os módulos Python.
- `python test_analyzer.py`: aprovado para conversão segura, similaridade e agrupamento de ativos.
- `node --check static/script.js`: aprovado.
- **Não foi possível executar teste de integração Flask nem chamar a API real:** Flask não estava instalado no ambiente de auditoria e não foram fornecidas chaves Twelve Data. Esses testes precisam ocorrer após instalar `requirements.txt` e configurar o serviço no Render.

## Riscos e itens a validar no deploy

- **Banco já existente:** `db.create_all()` não executa migrações de esquema. Faça backup e valide o esquema antes de apontar o novo app para um banco com tabelas existentes. O caminho mais seguro para um deploy limpo é criar um PostgreSQL novo.
- **Chave Fernet:** `ENCRYPTION_KEY` tem que ser a mesma no web e no worker e persistir. Perder/trocar a chave invalida a descriptografia das chaves armazenadas.
- **Candle fechado:** o cliente descarta o último registro como aproximação conservadora de candle ainda em formação. Conferir isso contra as respostas reais da Twelve Data antes de confiar no resultado.
- **Limite da API:** cada símbolo requer uma chamada de candles por ciclo; limites do plano e volume de usuários podem exigir menos pares, menor frequência ou otimização com endpoint batch.
- **Pares automáticos:** nesta entrega, a opção usa a lista padrão do servidor; não é uma descoberta ilimitada de todos os pares.
- **Disponibilidade do worker:** o serviço Background Worker precisa permanecer ativo. Se o Web Service estiver online mas o worker estiver parado, o botão pode gravar `ATIVA` sem resultados novos.
- **Blueprint:** revisar planos, nomes e variáveis em `render.yaml` na tela do Render antes de aplicar. Valores de plano/custo dependem das opções disponíveis na conta.

## Critérios de aceite após publicação

1. `/healthz` responde HTTP 200.
2. Dois e-mails distintos conseguem se cadastrar.
3. Configurações/chaves da conta A não aparecem na conta B.
4. Chave válida passa no teste; chave inválida falha com mensagem genérica.
5. Worker registra execução e atualiza resultados; o erro de cada usuário fica visível no painel.
6. Parar análise impede novos ciclos para aquele usuário.
7. Reiniciar web/worker mantém contas e credenciais legíveis.
